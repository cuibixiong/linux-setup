=============
 Deprecation
=============

.. el:package:: jedi

Deprecated configuration
========================

.. el:variable:: jedi:setup-keys
.. el:variable:: jedi:key-complete
   :value: (kbd "<C-tab>")
.. el:variable:: jedi:key-goto-definition
   :value: (kbd "C-.")
.. el:variable:: jedi:key-show-doc
   :value: (kbd "C-c d")
.. el:variable:: jedi:key-related-names
   :value: (kbd "C-c r")
.. el:variable:: jedi:key-goto-definition-pop-marker
   :value: (kbd "C-,")
