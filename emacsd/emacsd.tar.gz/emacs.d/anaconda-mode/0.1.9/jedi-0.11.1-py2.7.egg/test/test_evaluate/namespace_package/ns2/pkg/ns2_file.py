foo = 'ns2_file!'
